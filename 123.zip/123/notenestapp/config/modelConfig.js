const mongoose = require('mongoose');

// Ensure you have a valid MongoDB URI
const mongoURI = process.env.MONGO_URI || 'mongodb://localhost:27017/notenestapp';

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('connected', () => console.log('✅ MongoDB connected successfully'));
db.on('error', (err) => console.error('❌ MongoDB connection error:', err));

module.exports = db;
